# CyberTool

Educational Python project for local TCP diagnostics. In development.

## Features
- Local IPv4 loopback TCP scan
- Port service labels and local process information (Linux, when available)
- Progress display and persistent JSON scan history
- Interactive menu

## Usage
Requires Python 3. No external Python dependencies.

```sh
python3 cybertool.py
```

Choose 1 to inspect your own computer, 2 to read history, or 0 to exit. Service labels are conventional port names, not verified application identities. Process information may be incomplete depending on permissions.

History is stored locally in `historico.json` and excluded from Git.
